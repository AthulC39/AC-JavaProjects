
import java.util.Scanner;

public class seventhTask{

public static void main(String[] args){
Scanner input= new Scanner(System.in);
System.out.print("Enter three numbers: ");
int number1= input.nextInt();
int number2= input.nextInt();
int number3= input.nextInt();
{if(number1>2 && number2>number3){
  System.out.print("Numbers are in descending order");
}else
{if (number3>number2 && number2>number1){ 
  System.out.print("Numbers are in ascending order");
}else
 
 System.out.print("Numbers are in no particular order");
 


}

}
}
}

