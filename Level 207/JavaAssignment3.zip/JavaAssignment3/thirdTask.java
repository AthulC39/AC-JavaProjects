
import java.util.Scanner;

public class thirdTask{

public static void main(String[] args){
Scanner input= new Scanner(System.in);
System.out.print("Enter a number between 1 and 7");
int number= input.nextInt();
if (number==1){
    System.out.print("The first day of the week is Monday");
}
if (number==2){
    System.out.print("The second day of the week is Tuesday");
}
if (number==3) {
    System.out.print("The third day of the week is Wednesday");
}
if (number==4) {
    System.out.print("The fourth day of the week is Thursday");
}
if (number==5) {
    System.out.print("The fifth day of the week is Friday");
}
if (number==6) {
    System.out.print("The sixth day of the week is Saturday");
}
if (number==7) {
    System.out.print("The seventh day of the week is Saturday");
}
}
}
