
import java.util.Scanner;

public class firstTask{
public static void main(String[] args){
Scanner input= new Scanner(System.in);
int [] exToTheValueTen= new int[20];
System.out.println(exToTheValueTen.length);
}
}





