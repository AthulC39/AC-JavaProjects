
/**
 * Write a description of class Q1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class first
{
    public static void main(String[] args){
    String Name="Athul Charanthara";
    int YearofGraduation=2023;
    System.out.println(Name + " is graduating on year" + YearofGraduation);


    
} 
}
