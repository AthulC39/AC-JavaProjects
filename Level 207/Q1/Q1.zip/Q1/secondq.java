
public class secondq
{
    public static void main(String[] args){
    int firstValue=86;
    int secondValue=39;
    int sum=125;
    System.out.println( "The sum of " +  firstValue + " and " +  secondValue + " is " +  sum);

    
} 
}