
public class fourthq
{
    public static void main(String[] args){
    int a=-5+8;
    int b=55+9;
    int c=-3*5;
    int d=5+15/3*2;
    System.out.println(a*6);
    System.out.println(b/9);
    System.out.println(c/(8+20));
    System.out.println(d-8%3);
    
} 
}