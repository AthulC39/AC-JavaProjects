
public class ninthq
{
    public static void main(String[] args){
int num1=28;
int num2=43;
int num3=98;
int average=(num1+num2+num3)/3;
System.out.println("The Average of " + num1 + "," + num2 + "," + num3 + " is " + average);
    
    
} 
}