
public class tenthq
{
    public static void main(String[] args){
    int var1=6;
    int var2=8;
    int swap= var2=6;
    int swap2= var1=8;
    System.out.println("My variables are both " + var1 + " and " + var2);
    System.out.println( "When I swap them they become " + (var1-2) + " and " + (var2+2));
    
    
    
    
} 
}