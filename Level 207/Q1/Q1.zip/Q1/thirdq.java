
public class thirdq
{
    public static void main(String[] args){
    int firstNumber=27;
    int secondNumber=3;
    int dividend=9;
    System.out.println("The value of " + firstNumber + " divided by " + secondNumber + " is " + dividend);

    
} 
}