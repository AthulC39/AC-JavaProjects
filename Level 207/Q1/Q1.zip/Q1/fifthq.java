
public class fifthq
{
    public static void main(String[] args){
    int fahrenheit=68;
    int celsius=(fahrenheit-32)*5/9;
    System.out.println("The temperature outside today in fahrenheit is " + fahrenheit + " F");
    System.out.println("The temperature outside today in celsius is " + celsius + " C");
    
    
} 
}