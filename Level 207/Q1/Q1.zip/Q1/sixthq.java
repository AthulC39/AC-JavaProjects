
public class sixthq
{
    public static void main(String[] args){

    int square=2*2;
    int cube=2*2*2;
    int fourth=2*2*2*2;
    System.out.println("The Square of 2 is " + square);
    System.out.println("The cube of 2 is " + cube);
    System.out.println("2 to the power 4 is " + fourth);
    
    

    
} 
}