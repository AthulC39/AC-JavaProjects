
import java.util.Scanner;

public class firstTask{

public static void main(String[] args){
Scanner input= new Scanner(System.in);
System.out.println("Printing the first 10 natural numbers: ");
for (int i=1; i<=10; ++i) {
System.out.println(i);  
}
}
}
