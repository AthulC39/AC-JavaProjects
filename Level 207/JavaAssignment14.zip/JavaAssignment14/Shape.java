
 
abstract class Shape
{
 static double getAreaC(double d)
  {
      return 3.14*(d*d);
  }
  static double getAreaR(double d)
  {
      return d*d;
  }
  static double getPerimeterC(double d)
  {
      return 2*3.14*d;
  }
  static double getPerimeterR(double d)
  {
      return d*4;
  }
}
