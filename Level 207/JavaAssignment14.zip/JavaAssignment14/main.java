
 
public class main
{
  public static void main(String args[])
  {
      print obj = new print();
   obj.lunarCycleNumber();
    obj.lunarCycleName();
    obj.day();
    obj.year();
    obj.month();

  }
}
