

  class print implements time,lunarCycle
{
  public void day(){System.out.println("10th");}
  public void month(){System.out.println("January");}
  public void year(){System.out.println("2022");}
  public void lunarCycleNumber(){System.out.println("4");}
   public void lunarCycleName(){System.out.println("Wanning Gibbuos");}
}

