
 
public class Square extends Shape
{
     double side;
     double area= Shape.getAreaR(side);
     double perimeter= Shape.getPerimeterR(side);
     
}
