

public class Circle extends Shape
{
   double radius;
   double area= Shape.getAreaC(radius);
   double perimeter= Shape.getPerimeterC(radius);
}
