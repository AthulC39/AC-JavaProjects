
 
 interface lunarCycle
{
   void lunarCycleNumber();
   void lunarCycleName();
}
