

 interface time
{
   void day();
   void year();
   void month();

    }

