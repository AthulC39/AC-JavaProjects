

public class AP1ch061ab01a
{
 public static void main(String[] args)
 {
     int x=1;
     while(x <= 5)
     {
         System.out.print(x + "");
         x++;
        }
        System.out.println();
        System.out.println("x after the loop is completed =" + x);
        System.out.print("Bye");
 }
}

