import java.util.Scanner;
import java.util.Date;
public class secondTask{
public static void main(String[] args){
Date objDate = new Date();

System.out.println("The current time and date is " + objDate);
 
  }   
}
         
    

