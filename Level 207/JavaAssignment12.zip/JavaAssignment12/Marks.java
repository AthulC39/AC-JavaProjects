
public class Marks
{
  String[] names= new String[30];
  static int[] ScienceMarks= new int[30];
 static int[] EnglishMarks= new int[30];
  static int[] MathMarks= new int[30];
    }

