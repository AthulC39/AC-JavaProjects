public class Learner extends Trainer{
    String L_Name;
    int L_ID;
    
    
    
   void getName(){
       System.out.println(L_Name);
       
    }
    void getTID(){
        System.out.println(L_ID);
    }
}