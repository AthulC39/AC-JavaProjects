

public class Trainer
{
    String name;
    int T_ID;
    
    
    
   void getName(){
       System.out.println(name);
       
    }
    void getTID(){
        System.out.println(T_ID);
    }
    }

