public class Programmer extends Employee{
    String language;
}