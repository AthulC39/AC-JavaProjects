public class DatabasePro extends Employee{
    String databaseTool;
}