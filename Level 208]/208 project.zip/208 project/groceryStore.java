import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.CardLayout;
import java.awt.event.ActionListener;


public class groceryStore
{
   JFrame f = new JFrame("Swing Groceries Online Ordering!");
   JPanel panelCont = new JPanel();
   JPanel panelFirst = new JPanel();
   JPanel panelSecond = new JPanel();
   JButton buttonOne = new JButton("Browse Dairy and Grain options");
   JButton buttonSecond = new JButton("Browse Meat options");
   CardLayout cl = new CardLayout();
   public groceryStore() {
       panelCont.setLayout(cl);
       panelFirst.add(buttonOne);
       panelSecond.add(buttonSecond);
       panelCont.add(panelFirst,"`1");
       panelCont.add(panelSecond,"2");
       cl.show(panelCont,"1");
       
       buttonOne.addActionListener(new ActionListener());
       
   }
     public static void main(String args[])
    {
        groceryStore ob = new groceryStore();
        
        new groceryStore();
    }   
    }    
    

 
