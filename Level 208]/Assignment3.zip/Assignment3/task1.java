//1. concat()
//2. replace() method
