
import java.util.Scanner;
public class task6
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter two strings");
    String s=input.nextLine();
    String r= input.nextLine();
    char s1=s.charAt(0);
    char r1=r.charAt(r.length()-1);
    System.out.print(s1);
    System.out.print(r1);
 }

  }
        
 


