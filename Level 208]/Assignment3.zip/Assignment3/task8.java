
import java.util.Scanner;
public class task8
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
    System.out.println("enter your first and last name");
    String s=input.nextLine();
    String r=input.nextLine();
    System.out.println("Your first name has " + s.length() + " characters");
    System.out.println("Your last name has " + r.length() + " characters");
     
  
 }

  }
        
 


