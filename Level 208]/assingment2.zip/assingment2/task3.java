
import java.util.Scanner;
public class task3
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
     System.out.println("enter string");
     String s1="This is JAVA String";
     String replace=s1.replace('JAVA','Python');
       System.out.println(replace);
  
 }

  }
        
 


