
import java.util.Scanner;
public class task5
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
     System.out.println("String hi");
     System.out.println("String mom");
     String s1="hi";
     s1=s1.concat(",mom");
     
     System.out.println(s1);
  
 }

  }
        
 


