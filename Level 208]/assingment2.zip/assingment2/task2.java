
import java.util.Scanner;
public class task2
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter first string");
    String s=input.nextLine();
     System.out.println("Enter second string");
     System.out.println(s.contains(input.nextLine()));
  
 }

  }
        
 


