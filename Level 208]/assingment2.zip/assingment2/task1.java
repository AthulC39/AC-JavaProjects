
import java.util.Scanner;
public class task1
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
    System.out.println("enter a string");
    String s=input.nextLine();
    System.out.println("enter index");
    char n=s.charAt(input.nextInt()-1);
    System.out.println("The character at given index is: " + n);
    
    
  
 }

  }
        
 


