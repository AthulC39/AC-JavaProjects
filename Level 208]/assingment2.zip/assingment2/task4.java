
import java.util.Scanner;
public class task4
{
 

 public static void main(String[] args)
 {
    Scanner input = new Scanner(System.in);
     System.out.println("enter string");
     String s1=input.nextLine();
      String[] words=s1.split(",");
      System.out.println(words.length);
  
 }

  }
        
 


