

public class ansers
{
  //q1: JTable module is used in swing to make the tables
  //q2:add a new pane to the table
  //q3: If the mouse clicks a cetain text field in the tabel, switch to it
}
